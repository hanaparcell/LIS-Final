require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./models/db');
const app = express();
const PORT = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.send('Welcome to the Student Registry System!');
});


app.post('/add-course', (req, res) => {
    const { course_id, description, credit_hours } = req.body;
    if (!course_id || !description || !credit_hours) return res.status(400).send('All fields are required.');
    const query = 'INSERT INTO courses (course_id, description, credit_hours) VALUES (?, ?, ?)';
    db.query(query, [course_id, description, credit_hours], (err) => {
        if (err) return res.status(500).send('Error adding course');
        res.send('Course added successfully.');
    });
});

app.post('/delete-course', (req, res) => {
    const { course_id } = req.body;

    const query = 'DELETE FROM courses WHERE course_id = ?';

    db.query(query, [course_id], (err, result) => {
        if (err) return res.status(500).send('Error deleting course');
        if (result.affectedRows === 0) return res.status(404).send('Course not found');
        res.send('Course deleted successfully.');
    });
});

app.post('/enroll-student', (req, res) => {
    const { enrollment_id, student_name, student_birthday } = req.body;
    if (!enrollment_id || !student_name || !student_birthday) {
        return res.status(400).send('All fields are required.');
    }

    const query = 'INSERT INTO enrollments (enrollment_id, student_name, student_birthday) VALUES (?, ?, ?)';
    db.query(query, [enrollment_id, student_name, student_birthday], (err) => {
        if (err) return res.status(500).send('Error enrolling student');
        res.send('Student enrolled successfully.');
    });
});

app.post('/delete-student', (req, res) => {
    const { enrollment_id } = req.body;
    if (!enrollment_id) return res.status(400).send('Enrollment ID is required.');

    const query = 'DELETE FROM enrollments WHERE enrollment_id = ?';
    db.query(query, [enrollment_id], (err, result) => {
        if (err) return res.status(500).send('Error deleting student');
        if (result.affectedRows === 0) return res.status(404).send('Student not found');
        res.send('Student deleted successfully.');
    });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));